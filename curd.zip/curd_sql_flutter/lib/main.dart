import 'package:flutter/material.dart';
import 'package:curd_sql_flutter/ui/home_page.dart';

void main() {
  runApp(MaterialApp(
    home: HomePage(),
    debugShowCheckedModeBanner: false,
  ));
}

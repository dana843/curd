import 'package:curd_sql_flutter/helpers/sql_helper.dart';

class Data {
  // to define the variables
  int id;
  String title;
  String description;
  String img;
  Data();

  Data.fromMap(Map map) {
    id = map[idColumn];
    title = map[titleColumn];
    description = map[descriptionColumn];
    img = map[imgColumn];
  }

  Map toMap() {
    Map<String, dynamic> map = {
      titleColumn: title,
      descriptionColumn: description,
      imgColumn: img,
    };
    if (id != null) {
      map[idColumn] = id;
    }

    return map;
  }

  @override
  String toString() {
    return "Data(id: $id, title: $title,"
        " img: $img,description:$description,)";
  }
}
